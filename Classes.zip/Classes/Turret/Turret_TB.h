#include "Turret.h"
#include"cocos2d.h"
#include"Bullet.h"
#include"Monster.h"
#define DEBUG

USING_NS_CC;


class Turret_TB :public Turret {
	
};

